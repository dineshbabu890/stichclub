I Have Integrate the Code HTML to ReactJs (E-Commerce Customer App)

Step1: Install NodeJs 

Step2: Open Command Promot

Step3: Go the project Directory

Step4: Install Node_Modules 
        npm install
		
Step5:After run Project
        npm start 
