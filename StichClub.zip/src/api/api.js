const API_CONST = {
    DEV_URL : 'http://127.0.0.1:8000/',
    LOGIN_API : 'api/login/',
    CREATEACCOUNT_API : 'api/registration/'
}

export default API_CONST;