import React  from 'react';

export default function FormalQuestions(){
    console.log("oyyyyy")
    return(<h1>nooooooo</h1>)
}