import React, { Component } from 'react';
import Footer from '../components/Footer.jsx';
import Navbar from '../components/Navbar.jsx';


class Designerlogin extends Component {

  render() {
    return (
      <div>
        <Navbar />
       
        <section className="howtowork_section___14DE1 howtowork_gateway___M3NtF">

        <div className="limiter">
  <div className="container-login100">
    <div className="wrap-login100">
      <div className="login100-form-title" style={{backgroundImage: 'url(images/banner4.jpg)'}}>
        <span className="login100-form-title-1">
          Designer Log in
        </span>
      </div>
      <form className="login100-form validate-form">
        <div className="wrap-input100 validate-input m-b-26" data-validate="Username is required">
          <span className="label-input100">Username</span>
          <input className="input100" type="text" name="username" placeholder="Enter username" />
          <span className="focus-input100" />
        </div>
        <div className="wrap-input100 validate-input m-b-18" data-validate="Password is required">
          <span className="label-input100">Password</span>
          <input className="input100" type="password" name="password" placeholder="Enter password" />
          <span className="focus-input100" />
        </div>
        
        <div className="flex-sb-m w-full p-b-30">
          <div className="contact100-form-checkbox">
            <input className="input-checkbox100" id="ckb1" type="checkbox" name="remember-me" />
            <label className="label-checkbox100" htmlFor="ckb1">
              Remember me
            </label>
          </div>
          <div>
            <a href="" className="txt1">
              Forgot Password?
            </a>
          </div>
        </div>
        <div className="container-login100-form-btn">
          <button className="login100-form-btn">
            Log in
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

        
        </section>

    <Footer />

      </div>
    );
  }
}

export default Designerlogin