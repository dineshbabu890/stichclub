import React, { Component } from 'react';
import Footer from '../components/Footer.jsx';
import Navbar from '../components/Navbar.jsx';

class FAQ extends Component {
  render() {
    return (
      <div>
      <Navbar />
      <section className="main"><br /><br /><br />
      <div className="readysignup">
      <section className="readysignup_container">
        <div className="readysignup_background">
          <h1 className="">Frequntly Ask Questions ?</h1>
        </div>
      </section>
    </div>
    <br /><br />
    </section>
    <Footer />
    </div>

    );
  }
}

export default FAQ
